# Panel C

#### Para a execução do analisador sintático basta executar os seguintes comandos
```{sh}
make
```
```{sh}
./bin/panelc <testes/correto1.pc>
```
A extensão "pc" refere-se a um arquivo na lingugagem PanelC. Não há problemas em trocar por "txt".
